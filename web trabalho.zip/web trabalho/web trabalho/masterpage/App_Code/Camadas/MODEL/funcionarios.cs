﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace petshop.camadas.MODEL
{
    public class funcionarios
    {
        public int id { get; set; }
        public DateTime data { get; set; }
        public string cliente_id { get; set; }
        public string valorfinal { get; set; }
        public string produto_id { get; set; }
        

        

    }
    

}
