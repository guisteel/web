﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using petshop.camadas.MODEL;

namespace petshop.Camadas.BLL
{
   public class cliente
    {
        public List<camadas.MODEL.cliente> Select()
        {
           camadas.DAL.cliente dalCli = new camadas.DAL.cliente();

            return dalCli.Select();
        }

        public List<camadas.MODEL.cliente> SelectByid(int id)
        {
            camadas.DAL.cliente dalCli = new camadas.DAL.cliente();

            return dalCli.SelectByid(id);
        }

        public List<camadas.MODEL.cliente> SelectByNome(string nome)
        {
            camadas.DAL.cliente dalCli = new camadas.DAL.cliente();

            return dalCli.SelectBynome(nome);
        }

        public void insert(camadas.MODEL.cliente cliente)
        {
            camadas.DAL.cliente dalCli = new camadas.DAL.cliente();
            
            dalCli.btninsert(cliente);
        }

        public void editar(camadas.MODEL.cliente cliente)
        {
            camadas.DAL.cliente dalCli = new camadas.DAL.cliente();
            dalCli.editar(cliente);
        }

        public void excluir(camadas.MODEL.cliente cliente)
        {
            camadas.DAL.cliente dalCli = new camadas.DAL.cliente();

            dalCli.excluir(cliente);
        }

        internal List<camadas.MODEL.cliente> SelectByid(object id)
        {
            throw new NotImplementedException();
        }
    }
}
