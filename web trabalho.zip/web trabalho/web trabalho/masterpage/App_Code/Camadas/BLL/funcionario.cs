﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace petshop.Camadas.BLL
{
    public class funcionario
    {
        public List<camadas.MODEL.funcionarios> Select()
        {
            Camadas.DAL.funcionario dalfunc = new Camadas.DAL.funcionario();

            return dalfunc.Select();
        }

        public List<camadas.MODEL.funcionarios> SelectByid (int id)
        {
            Camadas.DAL.funcionario dalfunc = new Camadas.DAL.funcionario();

            return dalfunc.SelectByid(id);
        }

        public List<camadas.MODEL.funcionarios> SelectByNome(DateTime date)
        {
            Camadas.DAL.funcionario dalfunc = new Camadas.DAL.funcionario();

            return dalfunc.SelectBynome(date);
        }

        public void insert(camadas.MODEL.funcionarios funcionario)
        {
            Camadas.DAL.funcionario dalfunc = new Camadas.DAL.funcionario();

            dalfunc.insert(funcionario);
        }

        public void editar(camadas.MODEL.funcionarios funcionario)
        {
            Camadas.DAL.funcionario dalfunc = new Camadas.DAL.funcionario();
            dalfunc.editar(funcionario);
        }

        public void excluir(camadas.MODEL.funcionarios funcionario)
        {
            Camadas.DAL.funcionario dalfunc = new Camadas.DAL.funcionario();
            dalfunc.excluir(funcionario);

            dalfunc.excluir(funcionario);
        }

    }
}
