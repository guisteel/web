﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace petshop.Camadas.BLL
{
    public class mercadoria
    {

        public List<camadas.MODEL.mercadoria> Select()
        {
            Camadas.DAL.mercadoria dalmerca = new Camadas.DAL.mercadoria();

            return dalmerca.Select();
        }

        public List<camadas.MODEL.mercadoria> SelectByid(int id)
        {
            Camadas.DAL.mercadoria dalmerca = new Camadas.DAL.mercadoria();

            return dalmerca.SelectByid(id);
        }

        public List<camadas.MODEL.mercadoria> SelectByNome(string nome)
        {
            Camadas.DAL.mercadoria dalmerca = new Camadas.DAL.mercadoria();

            return dalmerca.SelectBynome(nome);
        }

        public void insert(camadas.MODEL.mercadoria mercadoria)
        {
            Camadas.DAL.mercadoria dalmerca = new Camadas.DAL.mercadoria();

            dalmerca.insert(mercadoria);
        }

        public void editar(camadas.MODEL.mercadoria mercadoria)
        {
            Camadas.DAL.mercadoria dalmerca = new Camadas.DAL.mercadoria();
            dalmerca.editar(mercadoria);
        }

        public void excluir(camadas.MODEL.mercadoria mercadoria)
        {
            Camadas.DAL.mercadoria dalmerca = new Camadas.DAL.mercadoria();
            dalmerca.excluir(mercadoria);

            dalmerca.excluir(mercadoria);
        }
    }
}
