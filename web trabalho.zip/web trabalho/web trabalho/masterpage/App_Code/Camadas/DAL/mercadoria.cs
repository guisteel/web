﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace petshop.Camadas.DAL
{
    public class mercadoria
    {

        private string strcon = camadas.DAL.conexao.getconexao();


        public List<camadas.MODEL.mercadoria> Select()
        {
            List<camadas.MODEL.mercadoria> lstmercadoria = new List<camadas.MODEL.mercadoria>();
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "select * from mercadorias";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    camadas.MODEL.mercadoria mercadoria = new camadas.MODEL.mercadoria();
                    mercadoria.id = Convert.ToInt32(reader[0].ToString());
                    mercadoria.nome = reader["nome"].ToString();
                    mercadoria.genero = reader["genero"].ToString();
                    mercadoria.quantidade = reader["quantidade"].ToString();
                    mercadoria.valor = reader["valor"].ToString();
                    
                    lstmercadoria.Add(mercadoria);
                }

            }
            catch
            {
                Console.WriteLine("Deu erro Na selecao de mercadoria");

            }
            finally
            {
                conexao.Close();

            }

            return lstmercadoria;
        }

        public void insert(camadas.MODEL.mercadoria mercadoria)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "insert into mercadorias values(@nome,@genero,@quantidade,@valor);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@nome", mercadoria.nome);
            cmd.Parameters.AddWithValue("@genero", mercadoria.genero);
            cmd.Parameters.AddWithValue("@quantidade", mercadoria.quantidade);
            cmd.Parameters.AddWithValue("@valor", mercadoria.valor);
            
            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine(" Erro na Inserçao de Produto");
            }
            finally
            {
                conexao.Close();

            }


        }

        public void editar(camadas.MODEL.mercadoria mercadoria)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Update mercadorias set nome=@nome, ";
            sql += "genero = @genero, quantidade = @quantidade, valor = @valor ";
            
            sql += "where id=@id ; ";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", mercadoria.id);
            cmd.Parameters.AddWithValue("@nome", mercadoria.nome);
            cmd.Parameters.AddWithValue("@genero", mercadoria.genero);
            cmd.Parameters.AddWithValue("@quantidade", mercadoria.quantidade);
            cmd.Parameters.AddWithValue("@valor", mercadoria.valor);
            

            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na atualização da mercadoria ");
            }
            finally
            {
                conexao.Close();

            }


        }

        public List<camadas.MODEL.mercadoria> SelectBynome(string nome)
        {
            DAL.mercadoria dalmerca = new DAL.mercadoria();

            return dalmerca.SelectBynome(nome);
        }

        public List<camadas.MODEL.mercadoria> SelectByid(int id)
        {
            DAL.mercadoria dalmerca = new DAL.mercadoria();

            return dalmerca.SelectByid(id);
        }


        public void excluir(camadas.MODEL.mercadoria mercadoria)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Delete from mercadorias where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", mercadoria.id);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na Remoção da mercadoria ");
            }
            finally
            {
                conexao.Close();
            }
        }
    }
}
