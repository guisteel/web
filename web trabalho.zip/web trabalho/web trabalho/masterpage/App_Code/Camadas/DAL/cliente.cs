﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using petshop.camadas.MODEL;

namespace petshop.camadas.DAL
{
    public class cliente
    {
        private string strcon = conexao.getconexao();

        public List<MODEL.cliente> Select()
        {
            List<MODEL.cliente> lstCliente = new List<MODEL.cliente>();
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "select * from clientes";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.cliente cliente = new MODEL.cliente();
                    cliente.id = Convert.ToInt32(reader[0].ToString());
                    cliente.nome = reader["nome"].ToString();
                    cliente.cpf = reader["cpf"].ToString();
                    cliente.endereco = reader["endereco"].ToString();
                    cliente.numero = reader["numero"].ToString();
                    cliente.cidade = reader["cidade"].ToString();
                    cliente.estado = reader["estado "].ToString();
                    cliente.telefone = reader["telefone"].ToString();
                    
                    lstCliente.Add(cliente);
                }

            }
            catch
            {
                Console.WriteLine("Deu erro Na selecao de clientes");

            }
            finally
            {
                conexao.Close();

            }

            return lstCliente;

        }
        public void btninsert(MODEL.cliente cliente)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "insert into clientes values(@nome,@cpf,@endereco,@numero,@cidade,@estado,@telefone);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@nome", cliente.nome);
            cmd.Parameters.AddWithValue("@cpf", cliente.cpf);
            cmd.Parameters.AddWithValue("@endereco", cliente.endereco);
            cmd.Parameters.AddWithValue("@numero", cliente.numero);
            cmd.Parameters.AddWithValue("@cidade", cliente.cidade);
            cmd.Parameters.AddWithValue("@estado", cliente.estado);
            cmd.Parameters.AddWithValue("@telefone", cliente.estado);
            
            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine(" Erro na Inserçao de Clientes");
            }
            finally
            {
                conexao.Close();

            }


        }

        public void editar(MODEL.cliente cliente)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Update clientes set nome=@nome, ";
            sql += "cpf=@cpf , endereco=@endereco, numero=@numero, cidade=@cidade, estado=@estado, ";
            sql += " telefone=@telefone ";
            sql += " where id=@id ; ";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", cliente.id);
            cmd.Parameters.AddWithValue("@nome", cliente.nome);
            cmd.Parameters.AddWithValue("@cpf", cliente.cpf);
            cmd.Parameters.AddWithValue("@endereco", cliente.endereco);
            cmd.Parameters.AddWithValue("@numero", cliente.numero);
            cmd.Parameters.AddWithValue("@cidade", cliente.cidade);
            cmd.Parameters.AddWithValue("@estado", cliente.estado);
            cmd.Parameters.AddWithValue("@telefone", cliente.telefone);
            
            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na atualização do cliente ");
            }
            finally
            {
                conexao.Close();

            }


        }

        public List<MODEL.cliente> SelectBynome(string nome)
        {
            List<MODEL.cliente> lstCliente = new List<MODEL.cliente>();
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Select * from Clientes where (nome like @nome);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@nome", nome.Trim() + "%");
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.cliente cliente = new MODEL.cliente();
                    cliente.id = Convert.ToInt32(reader[0].ToString());
                    cliente.nome = reader["nome"].ToString();
                    cliente.cpf = reader["cpf"].ToString();
                    cliente.endereco = reader["endereco"].ToString();
                    cliente.numero = reader["numero"].ToString();
                    cliente.cidade = reader["cidade"].ToString();
                    cliente.estado = reader["estado"].ToString();
                    cliente.telefone = reader["telefone"].ToString();
                    
                    lstCliente.Add(cliente);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Clientes por Nome...");
            }
            finally
            {
                conexao.Close();
            }

            return lstCliente;
        }

        private List<MODEL.cliente> SelectByNome(string nome)
        {
            throw new NotImplementedException();
        }

        public List<MODEL.cliente> SelectByid(int id)
        {
            List<MODEL.cliente> lstCliente = new List<MODEL.cliente>();
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Select * from clientes where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", id);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.cliente cliente = new MODEL.cliente();
                    cliente.id = Convert.ToInt32(reader[0].ToString());
                    cliente.nome = reader["nome"].ToString();
                    cliente.cpf = reader["cpf"].ToString();
                    cliente.endereco = reader["endereco"].ToString();
                    cliente.numero = reader["numero"].ToString();
                    cliente.cidade = reader["cidade"].ToString();
                    cliente.estado = reader["estado"].ToString();
                    cliente.telefone = reader["telefone"].ToString();
                    
                    lstCliente.Add(cliente);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Clientes por ID...");
            }
            finally
            {
                conexao.Close();
            }

            return lstCliente;
        }

        public void excluir(MODEL.cliente cliente)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Delete from Clientes where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", cliente.id);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na Remoção de Clientes");
            }
            finally
            {
                conexao.Close();
            }
        }

    }
}
    


