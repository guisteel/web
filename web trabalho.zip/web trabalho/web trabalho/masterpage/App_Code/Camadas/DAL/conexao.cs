﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace petshop.camadas.DAL
{
    public class conexao
    {
        public static string getconexao()
        {
            return @"Data Source=.\sqlexpress;Initial Catalog=petshop;Integrated Security=True";
        }
    }
}
