﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using petshop.camadas.MODEL;

namespace petshop.Camadas.DAL
{
    public class funcionario
    {
        private string strcon = camadas.DAL.conexao.getconexao();
        

        public List<camadas.MODEL.funcionarios> Select()  
            {
                List<camadas.MODEL.funcionarios> lstfuncionario = new List<camadas.MODEL.funcionarios>();
                SqlConnection conexao = new SqlConnection(strcon);
                string sql = "select * from funcionarios";
                SqlCommand cmd = new SqlCommand(sql, conexao);
                conexao.Open();
                try
                {
                    SqlDataReader reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                    while (reader.Read())
                    {
                        camadas.MODEL.funcionarios funcionario = new camadas.MODEL.funcionarios();
                        funcionario.id = Convert.ToInt32(reader[0].ToString());
                        funcionario.data = Convert.ToDateTime( reader["data"].ToString());
                        funcionario.cliente_id = reader["cliente_id"].ToString();
                        funcionario.valorfinal = reader["valorfinal"].ToString();
                        funcionario.produto_id = reader["produto_id"].ToString();
                        
                        lstfuncionario.Add(funcionario);
                    }

                }
                catch
                {
                    Console.WriteLine("Deu erro Na selecao da venda");

                }
                finally
                {
                    conexao.Close();

                }

                return lstfuncionario;
            }
       
        public void insert(camadas.MODEL.funcionarios funcionario)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "insert into funcionarios values(@date,@cliente_id,@valorfinal,@produto_id);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@date", funcionario.data);
            cmd.Parameters.AddWithValue("@cliente_id", funcionario.cliente_id);
            cmd.Parameters.AddWithValue("@valorfinal", funcionario.valorfinal);
            cmd.Parameters.AddWithValue("@produto_id", funcionario.produto_id);
            
            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine(" Erro na Inserçao da Venda");
            }
            finally
            {
                conexao.Close();

            }


        }

        public void editar(camadas.MODEL.funcionarios funcionario)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Update funcionarios set date=@date, ";
            sql += "cliente_id = @cliente_id, valorfinal =@valorfinal, produto_id =@produto_id ";
            sql += "where id=@id ; ";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", funcionario.id);
            cmd.Parameters.AddWithValue("@date", funcionario.data);
            cmd.Parameters.AddWithValue("@cliente_id", funcionario.cliente_id);
            cmd.Parameters.AddWithValue("@valorfinal", funcionario.valorfinal);
            cmd.Parameters.AddWithValue("@produto_id", funcionario.produto_id);
            

            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na atualização da Venda ");
            }
            finally
            {
                conexao.Close();

            }


        }

        public List<camadas.MODEL.funcionarios> SelectBynome(DateTime data)
        {
            DAL.funcionario dalfunc = new DAL.funcionario();

            return dalfunc.SelectBynome(data);
        }

        public List<camadas.MODEL.funcionarios> SelectByid(int id)
        {
            DAL.funcionario dalfunc = new DAL.funcionario();

            return dalfunc.SelectByid(id);
        }


        public void excluir(camadas.MODEL.funcionarios funcinario)
        {
            SqlConnection conexao = new SqlConnection(strcon);
            string sql = "Delete from funcionarios where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", funcinario.id);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na Remoção da Venda");
            }
            finally
            {
                conexao.Close();
            }
        }

    }
}
   

